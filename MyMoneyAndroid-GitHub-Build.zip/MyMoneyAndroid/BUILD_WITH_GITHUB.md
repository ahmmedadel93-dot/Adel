# Build My Money APK without Android Studio

This project contains a GitHub Actions workflow that builds a **debug APK** on GitHub's servers. No Android Studio installation is needed.

1. Sign in to https://github.com and create a new **private** repository named `my-money-android`. Do **not** check 'Add a README'.
2. Extract the supplied ZIP on your computer. Open the `MyMoneyAndroid` folder, and upload **the contents of that folder** to the root of the GitHub repository using **Add file → Upload files**. Be sure to include the hidden `.github/workflows/build-apk.yml` file; some file pickers hide folders starting with a dot. If necessary, create this file using GitHub's **Add file → Create new file**, with the full path `.github/workflows/build-apk.yml`, and paste the workflow content from the downloaded project.
3. Commit the files to `main`. Open the **Actions** tab. Select **Build My Money APK** and click **Run workflow**. (The initial push to main may also start a build automatically.)
4. Wait until the workflow has a green check. Open the run, scroll to **Artifacts**, and download `MyMoney-Android-APK` (a ZIP).
5. Extract that ZIP to get `app-debug.apk`. Transfer it to your Android phone, open it, and follow Android's prompt to allow installation from that source. Use only the APK you built yourself.
6. Open My Money, create accounts, enter the exact bank SMS sender IDs under **Bank SMS settings**, and grant SMS permission. Only new incoming supported messages are imported.

If the build is red, open the failed step and read the error logs. This package has not been compiled or tested on a device in this environment.

## Important limitations
- The APK is a debug build, for personal testing/sideloading, **not** a Google Play release.
- Your financial records remain locally on the phone; GitHub only builds the source code and does not receive your bank SMS.
- The SMS importer is a generic starter parser. It may miss or misclassify bank messages; do not rely on it without testing with your bank's actual redacted SMS format.
- Sender IDs can be spoofed. Verify transactions against statements.
- Current importer uses the first account of the same currency, so multi-bank balances may be inaccurate until sender-to-account mapping is added.
- Uninstalling may delete local data. Export your transactions regularly; full backup/restore is not implemented.
