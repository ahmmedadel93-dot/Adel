# My Money — Android personal finance tracker

Android Studio Java project, offline SQLite data. This is source code, **not a compiled APK**.

## Build and install
1. Install Android Studio on a Windows, Mac, or Linux computer.
2. Extract this ZIP and open the `MyMoneyAndroid` directory as a project.
3. Let Android Studio download Gradle/Android SDK dependencies; use JDK 17.
4. Connect an Android phone with USB debugging enabled, and press **Run**. Or select **Build > Build APK(s)** and install the resulting APK on your device, accepting Android's sideload prompts.
5. In the app, create your bank accounts and starting balances, then open **Bank SMS settings**. Enter the **exact** sender IDs used by your bank (e.g., the name/shortcode displayed as the sender), save, and grant SMS permission. SMS import is **off** until you add sender IDs.
6. Test the parser with a sanitized example message before relying on it. It imports only newly received SMS; it does not read SMS history.

## SMS limits and security
- Android RECEIVE_SMS permission is needed for automatic new-message import. Some Android distributions, security policies, and Google Play restrictions may block this permission or distribution. Intended for personal sideload use.
- Bank formats differ. Only messages containing a recognized debit/credit term and a currency-adjacent amount are imported. Ambiguous messages are ignored. Multi-part SMS is combined.
- Matching is exact sender ID allowlisting; sender IDs can be spoofed. SMS parsing is **not a verified bank integration**. Check imported transactions against your bank statement.
- Full SMS text is not saved, and no SMS is uploaded. A SHA-256 message fingerprint is stored for duplicate prevention. No network permission is requested.
- Each imported SMS is assigned to the **first account of matching currency**. If you have multiple banks using the same currency, manually correct the entry or extend the receiver with sender-to-account mapping before using it for accurate bank balances.
- Cash withdrawals can be classified as expenses by SMS. To avoid double counting, record them as transfers instead when moving cash between your own accounts. Transfers are represented by paired transaction entries and can affect category totals if not excluded.
- App data is stored locally in private SQLite. Uninstalling the app removes its data. CSV export is provided for transactions, but this version does not yet have full-database restore/backup.
- Recurring entries are manually posted; no background auto-charge is performed.
- Exchange rate setting is informational; no combined-currency valuation is calculated yet.

## Sample SMS parsing
`Your card was debited EGP 250.00 for purchase` -> expense, EGP 250.
`Your account was credited USD 100.00 salary` -> income, USD 100.

## Scope
Includes accounts, manual transactions, transfers, recurring templates, budgets, month-to-date summaries, SMS receiver and CSV sharing. This is a functional **starter application**, not a production-audited financial system. Review all bank-derived entries.
