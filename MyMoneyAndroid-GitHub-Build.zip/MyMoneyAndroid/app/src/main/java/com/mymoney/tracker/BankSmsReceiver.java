package com.mymoney.tracker;

import android.content.*;
import android.provider.Telephony;
import android.telephony.SmsMessage;
import java.security.MessageDigest;
import java.util.*;
import java.util.regex.*;

public class BankSmsReceiver extends android.content.BroadcastReceiver {
 private static final Pattern AMOUNT=Pattern.compile("(?i)(?:EGP|LE|USD|ج\\.?م|جنيه|دولار)\\s*([0-9][0-9,]*(?:\\.[0-9]{1,2})?)|([0-9][0-9,]*(?:\\.[0-9]{1,2})?)\\s*(?:EGP|LE|USD|ج\\.?م|جنيه|دولار)");
 public static class Parsed {public double amount;public String currency,kind,category;}
 public static Parsed parse(String body){
  String l=body.toLowerCase(Locale.ROOT);boolean debit=Pattern.compile("(?i)\\b(purchase|spent|withdrawn|withdrawal|debited|debit|payment|paid|pos|atm)\\b|شراء|سحب|خصم|دفع|مدين").matcher(l).find();
  boolean credit=Pattern.compile("(?i)\\b(credited|credit|deposit|received|salary|refund)\\b|إيداع|ايداع|إضافة|اضافة|وارد|راتب|مرتب").matcher(l).find();
  if(debit==credit)return null;
  Matcher m=AMOUNT.matcher(body);if(!m.find())return null;
  String raw=m.group(1)!=null?m.group(1):m.group(2);double value;try{value=Double.parseDouble(raw.replace(",",""));}catch(Exception e){return null;}if(value<=0)return null;
  String currency=l.contains("usd")||l.contains("دولار")?"USD":"EGP";
  Parsed p=new Parsed();p.amount=value;p.currency=currency;p.kind=debit?"expense":"income";
  p.category=debit?(l.contains("atm")||l.contains("سحب")?"Cash Withdrawal":"Bank Spending"):(l.contains("salary")||l.contains("راتب")||l.contains("مرتب")?"Salary":"Bank Income");return p;
 }
 static String hash(String input){try{byte[] b=MessageDigest.getInstance("SHA-256").digest(input.getBytes("UTF-8"));StringBuilder s=new StringBuilder();for(byte x:b)s.append(String.format(Locale.US,"%02x",x&255));return s.toString();}catch(Exception e){return String.valueOf(input.hashCode());}}
 @Override public void onReceive(Context context,Intent intent){if(!Telephony.Sms.Intents.SMS_RECEIVED_ACTION.equals(intent.getAction()))return;
  MoneyDb db=new MoneyDb(context);String allowed=db.setting("senders","").trim();if(allowed.isEmpty())return; // Explicit sender allowlist required
  SmsMessage[] messages=Telephony.Sms.Intents.getMessagesFromIntent(intent);if(messages==null||messages.length==0)return;
  StringBuilder body=new StringBuilder();String sender=messages[0].getDisplayOriginatingAddress();if(sender==null)return;
  boolean ok=false;for(String token:allowed.split(",")){if(!token.trim().isEmpty()&&sender.equalsIgnoreCase(token.trim()))ok=true;}if(!ok)return;
  long time=messages[0].getTimestampMillis();for(SmsMessage msg:messages)body.append(msg.getDisplayMessageBody());
  Parsed p=parse(body.toString());if(p==null)return;long account=db.defaultAccount(p.currency);if(account<0)return;
  // Full SMS never stored. A hash prevents repeated inserts from the same received message.
  String fingerprint=hash(sender+"|"+time+"|"+body.toString());
  db.addTransaction(account,p.amount,p.kind,p.category,"Bank SMS · "+sender,time,"sms",fingerprint);
 }
}
