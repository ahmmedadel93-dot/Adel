package com.mymoney.tracker;

import android.content.*;
import android.database.*;
import android.database.sqlite.*;
import java.util.*;

public class MoneyDb extends SQLiteOpenHelper {
 public MoneyDb(Context c){super(c,"my_money.db",null,1);}
 @Override public void onCreate(SQLiteDatabase d){
  d.execSQL("CREATE TABLE accounts(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,currency TEXT NOT NULL,opening REAL NOT NULL DEFAULT 0)");
  d.execSQL("CREATE TABLE transactions(id INTEGER PRIMARY KEY AUTOINCREMENT,account_id INTEGER NOT NULL,amount REAL NOT NULL,kind TEXT NOT NULL,category TEXT NOT NULL,note TEXT NOT NULL,occurred INTEGER NOT NULL,source TEXT NOT NULL DEFAULT 'manual',fingerprint TEXT UNIQUE)");
  d.execSQL("CREATE TABLE budgets(id INTEGER PRIMARY KEY AUTOINCREMENT,category TEXT NOT NULL,currency TEXT NOT NULL,monthly_limit REAL NOT NULL,UNIQUE(category,currency))");
  d.execSQL("CREATE TABLE recurring(id INTEGER PRIMARY KEY AUTOINCREMENT,account_id INTEGER NOT NULL,amount REAL NOT NULL,kind TEXT NOT NULL,category TEXT NOT NULL,note TEXT NOT NULL,day_of_month INTEGER NOT NULL)");
  d.execSQL("CREATE TABLE settings(key TEXT PRIMARY KEY,value TEXT NOT NULL)");
  d.execSQL("INSERT INTO accounts(name,currency,opening) VALUES('Cash','EGP',0)");
  d.execSQL("INSERT INTO settings(key,value) VALUES('usd_egp','50')");
 }
 @Override public void onUpgrade(SQLiteDatabase d,int old,int next){}
 public synchronized long addTransaction(long account,double amount,String kind,String category,String note,long when,String source,String fingerprint){
  ContentValues v=new ContentValues();v.put("account_id",account);v.put("amount",amount);v.put("kind",kind);v.put("category",category);v.put("note",note);v.put("occurred",when);v.put("source",source);if(fingerprint!=null)v.put("fingerprint",fingerprint);
  return getWritableDatabase().insertWithOnConflict("transactions",null,v,SQLiteDatabase.CONFLICT_IGNORE);
 }
 public synchronized long addAccount(String name,String currency,double opening){ContentValues v=new ContentValues();v.put("name",name);v.put("currency",currency);v.put("opening",opening);return getWritableDatabase().insert("accounts",null,v);}
 public synchronized List<String> accountLabels(){List<String> a=new ArrayList<>();try(Cursor c=getReadableDatabase().rawQuery("SELECT id,name,currency FROM accounts ORDER BY id",null)){while(c.moveToNext())a.add(c.getLong(0)+" · "+c.getString(1)+" ("+c.getString(2)+")");}return a;}
 public synchronized long defaultAccount(String currency){try(Cursor c=getReadableDatabase().rawQuery("SELECT id FROM accounts WHERE currency=? ORDER BY id LIMIT 1",new String[]{currency})){return c.moveToFirst()?c.getLong(0):-1;}}
 public synchronized String accountCurrency(long id){try(Cursor c=getReadableDatabase().rawQuery("SELECT currency FROM accounts WHERE id=?",new String[]{String.valueOf(id)})){return c.moveToFirst()?c.getString(0):"EGP";}}
 public synchronized void budget(String category,String currency,double limit){getWritableDatabase().execSQL("INSERT OR REPLACE INTO budgets(category,currency,monthly_limit) VALUES(?,?,?)",new Object[]{category,currency,limit});}
 public synchronized void recurring(long account,double amount,String kind,String category,String note,int day){getWritableDatabase().execSQL("INSERT INTO recurring(account_id,amount,kind,category,note,day_of_month) VALUES(?,?,?,?,?,?)",new Object[]{account,amount,kind,category,note,day});}
 public synchronized void setting(String key,String value){getWritableDatabase().execSQL("INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)",new Object[]{key,value});}
 public synchronized String setting(String key,String fallback){try(Cursor c=getReadableDatabase().rawQuery("SELECT value FROM settings WHERE key=?",new String[]{key})){return c.moveToFirst()?c.getString(0):fallback;}}
 public synchronized String report(){StringBuilder s=new StringBuilder();long now=System.currentTimeMillis();Calendar cal=Calendar.getInstance();cal.setTimeInMillis(now);cal.set(Calendar.DAY_OF_MONTH,1);cal.set(Calendar.HOUR_OF_DAY,0);cal.set(Calendar.MINUTE,0);cal.set(Calendar.SECOND,0);cal.set(Calendar.MILLISECOND,0);long start=cal.getTimeInMillis();
  s.append("ACCOUNTS\n");try(Cursor c=getReadableDatabase().rawQuery("SELECT a.name,a.currency,a.opening+COALESCE(SUM(CASE WHEN t.kind='income' THEN t.amount WHEN t.kind='expense' THEN -t.amount ELSE 0 END),0) FROM accounts a LEFT JOIN transactions t ON t.account_id=a.id GROUP BY a.id ORDER BY a.id",null)){while(c.moveToNext())s.append(c.getString(0)).append(": ").append(String.format(Locale.US,"%,.2f",c.getDouble(2))).append(" ").append(c.getString(1)).append("\n");}
  s.append("\nTHIS MONTH\n");try(Cursor c=getReadableDatabase().rawQuery("SELECT a.currency,t.kind,SUM(t.amount) FROM transactions t JOIN accounts a ON a.id=t.account_id WHERE t.occurred>=? GROUP BY a.currency,t.kind ORDER BY a.currency,t.kind",new String[]{String.valueOf(start)})){while(c.moveToNext())s.append(c.getString(1)).append(": ").append(String.format(Locale.US,"%,.2f",c.getDouble(2))).append(" ").append(c.getString(0)).append("\n");}
  s.append("\nBUDGETS (THIS MONTH)\n");try(Cursor c=getReadableDatabase().rawQuery("SELECT b.category,b.currency,b.monthly_limit,COALESCE((SELECT SUM(t.amount) FROM transactions t JOIN accounts a ON a.id=t.account_id WHERE t.kind='expense' AND t.category=b.category AND a.currency=b.currency AND t.occurred>=?),0) FROM budgets b ORDER BY b.category",new String[]{String.valueOf(start)})){while(c.moveToNext())s.append(c.getString(0)).append(" ").append(c.getString(1)).append(": ").append(String.format(Locale.US,"%,.0f / %,.0f",c.getDouble(3),c.getDouble(2))).append("\n");}
  s.append("\nRECENT TRANSACTIONS\n");try(Cursor c=getReadableDatabase().rawQuery("SELECT datetime(t.occurred/1000,'unixepoch','localtime'),t.kind,t.amount,a.currency,t.category,t.note,t.source FROM transactions t JOIN accounts a ON a.id=t.account_id ORDER BY t.occurred DESC,t.id DESC LIMIT 35",null)){while(c.moveToNext())s.append(c.getString(0)).append("  ").append(c.getString(1)).append(" ").append(String.format(Locale.US,"%,.2f",c.getDouble(2))).append(" ").append(c.getString(3)).append(" · ").append(c.getString(4)).append(" · ").append(c.getString(5)).append(" [").append(c.getString(6)).append("]\n");}
  return s.toString();}
}
